"Error 51 - ifTrue:ifFalse: argument does not understand value message"
class Main : Object {
    run [|
        _ := true ifTrue: 42 ifFalse: 99.
    ]
}
