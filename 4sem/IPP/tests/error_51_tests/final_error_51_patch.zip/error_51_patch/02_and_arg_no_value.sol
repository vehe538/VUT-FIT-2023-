"Error 51 - and: argument does not understand value message"
class Main : Object {
    run [|
        _ := true and: 'not a block'.
    ]
}
