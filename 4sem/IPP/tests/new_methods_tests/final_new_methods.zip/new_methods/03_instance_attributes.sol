"Testing instance attributes - setting and reading via messages"
class Main : Object {
    run [|
        _ := self name: 'Alice'.
        _ := self age: 30.
        _ := (self name) print.
        _ := ((self age) asString) print.
        _ := self age: 31.
        _ := ((self age) asString) print.
    ]
}
