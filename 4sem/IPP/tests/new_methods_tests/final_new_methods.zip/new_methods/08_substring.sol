"Testing startsWith:endsBefore: substring extraction"
class Main : Object {
    run [|
        s := 'Hello World'.
        sub1 := s startsWith: 1 endsBefore: 6.
        _ := sub1 print.
        sub2 := s startsWith: 7 endsBefore: 12.
        _ := sub2 print.
        sub3 := s startsWith: 7 endsBefore: 100.
        _ := sub3 print.
        sub4 := s startsWith: 5 endsBefore: 3.
        _ := sub4 print.
    ]
}
