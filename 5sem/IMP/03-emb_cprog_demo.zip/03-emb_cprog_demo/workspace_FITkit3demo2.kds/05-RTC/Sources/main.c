#include "MK60D10.h"
#include "mcg.h"
#include "io.h"
#include "uart.h"

#define TRUE 1

void rtc_init(uint32_t seconds, uint32_t alarm, uint8_t c_interval, uint8_t c_value, uint8_t interrupt) {
	unsigned int i;

	/* enable RTC clock */
	SIM->SCGC6 |= SIM_SCGC6_RTC_MASK;
	printf("\r\nRTC module register space clock enabled ...\r\n");

	/* reset RTC registers */
	RTC->CR  = RTC_CR_SWR_MASK;
	RTC->CR  &= ~RTC_CR_SWR_MASK;
	printf("RTC module reset done ...\r\n");

	/* configure RTC interrupts */
	NVIC_ClearPendingIRQ(66);
	NVIC_EnableIRQ(66);
	printf("NVIC interrupt for RTC module enabled ...\r\n");

	/* enable RTC oscillator */
	RTC->CR |= RTC_CR_OSCE_MASK;
	printf("RTC module oscillator enabled ...\r\n");

	/* wait until 32 kHz gets stable / refer to the crystal startup time in the crystal datasheet */
	 for(i=0; i<0x600000; i++);
	printf("RTC module oscillator stable ...\r\n\n");

	/* compensation of RTC parameters, if needed */
	RTC->TCR = RTC_TCR_CIR(c_interval) | RTC_TCR_TCR(c_value);

	/* configure seconds/alarm registers of RTC */
	RTC->TSR = seconds;
	RTC->TAR = alarm;

	/* The interrupt enable flag should be set implicitly after MCU reset, 
     but we can set it explicitly too */
	RTC->IER |= RTC_IER_TAIE_MASK;

	/* enable RTC counter */
	RTC->SR |= RTC_SR_TCE_MASK;
}

extern void RTC_IRQHandler() {

   if((RTC->SR & RTC_SR_TIF_MASK)== 0x01)
     {
       printf("RTC time invalid interrupt ...\r\n");
   	   RTC->SR &= 0x07;  // clear TCE; else RTC_TSR cannot be written
   	   RTC->TSR = 0x00000000;  //clear TIF
     }
   else if((RTC->SR & RTC_SR_TOF_MASK) == 0x02)
   {
   	   printf("RTC time overflow interrupt ...\r\n");
   	   RTC->SR &= 0x07;  // clear TCE; else RTC_TSR cannot be written
   	   RTC->TSR = 0x00000000;  //clear TOF
   }
   else if((RTC->SR & RTC_SR_TAF_MASK) == 0x04)
   {
   	   printf("RTC alarm interrupt ...\r\n");
       printf("Time Seconds Register value is: %i\n", RTC->TSR);
   	   RTC->TAR += 1; // increment the alarm value to generate an alarm after the next second expires
   }
   else
   {
	   printf("No valid flag was set !\n");
   }
}

int main (void) {
	// Switching from FEI mode (default after restart) to BPLE mode: 
  // 20.97 MHz -> 50 MHz
	MCG_FEI_BLPE();

	// Enable clock for PORTE, configure the TX and RX pins for UART5
	SIM->SCGC5 = SIM_SCGC5_PORTE_MASK;
	PORTE->PCR[8] = PORT_PCR_MUX(0x03);
	PORTE->PCR[9] = PORT_PCR_MUX(0x03);

	// Initialize the UART.
	// Use TERM_PORT = UART3_BASE_PTR for the 9pin serial port. (Defined in uart.h)
	// Configure for 50 MHz peripheral clock and 115200 target baud rate.
	uart_init(TERM_PORT, 50000, 115200);

  	printf("\r\nRunning RTC example !!!\n");
  	printf("This example generates an interrupt request (IRQ) each second !\n");

    /* Parameters:
     *  seconds         Start value of seconds register
     *  alarm           Time in seconds of first alarm. Set to 0xFFFFFFFF to effectively disable alarm
     *  c_interval      Interval at which to apply time compensation can range from 1 second (0x0) to 256 (0xFF)
     *  c_value         Compensation value ranges from -127 32kHz cycles to +128 32 kHz cycles
     *                  80h Time prescaler register overflows every 32896 clock cycles.
     *                  FFh Time prescaler register overflows every 32769 clock cycles.
     *                  00h Time prescaler register overflows every 32768 clock cycles.
     *                  01h Time prescaler register overflows every 32767 clock cycles.
     *                  7Fh Time prescaler register overflows every 32641 clock cycles.
     *  interrupt       TRUE or FALSE
     */
  	rtc_init(0, 0, 0, 0, TRUE);

  	for(;;) {
  		// Wait until a key is pressed
  		while(char_present() == 0);

  		// Print to the terminal which key was pressed.
  		printf("You have pressed '%c'\n\r", in_char());
  	}

	return 0;
}
