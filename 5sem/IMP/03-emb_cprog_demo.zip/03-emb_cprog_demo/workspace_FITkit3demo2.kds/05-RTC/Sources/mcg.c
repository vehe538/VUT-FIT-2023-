#include "MK60D10.h"
#include "mcg.h"

/*
 *	Sets the Multipurpose Clock Generator (MCG) into the Bypassed Low Power 
 *	External (BLPE) mode from FEI mode -> 50 MHz.
 */
void MCG_FEI_BLPE() {
	// Select External Reference Clock in MCG (Transition to FBE from FEI)
	MCG->C1 = MCG_C1_CLKS(2);

	// Wait for Reference clock to switch to external reference
	while (MCG->S & MCG_S_IREFST_MASK);

	// Wait for MCGOUT to switch into the external reference clock mode
	while (((MCG->S & MCG_S_CLKST_MASK) >> MCG_S_CLKST_SHIFT) != 0x2);

	// Switching to the Bypassed - FLL/PLL off - low power external mode (BLPE)
	MCG->C2 = MCG_C2_LP_MASK;
}

/*
 *	Sets the Multipurpose Clock Generator (MCG) into the FLL Engaged Internal 
 *	(FEI) mode from BLPE mode -> 20.97 MHz.
 *
 */
void MCG_BLPE_FEI() {
	// Transition to FBE
	MCG->C2 = 0;

	// Transition to FEI
	MCG->C1 = MCG_C1_IREFS_MASK;

	// Wait for Reference clock to switch to internal reference
	while ((MCG->S & MCG_S_IREFST_MASK) == 0);

	// Wait for MCGOUT to switch over to the FLL clock
	while (((MCG->S & MCG_S_CLKST_MASK) >> MCG_S_CLKST_SHIFT) != 0x0);
}
