ims

pro spusteni spravneho experimentu, zavolejte v mainu funkci pro jejich nastaveni (napr. setDefaultOptions();).