import { piskvorky } from "../customAPI.ts";

export const api = new piskvorky(3, 3);