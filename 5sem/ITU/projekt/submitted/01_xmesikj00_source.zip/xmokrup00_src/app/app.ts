import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SquareTable } from './square-table/square-table';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, SquareTable],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected readonly title = signal('piskvorky_app');
}
