
export class piskvorky {

    public playboard!: any[][];
    public player!: string;
    public size!: number;
    public squares_to_win!: number;
    public win_coords_x: number | null = null;
    public win_coords_y: number | null = null;
    public win_line_code: string | null = null;

    public cpu_opponent: boolean = false;
    public last_cpu_move: {row: number, col: number} | null = null;

    constructor(size: number, squares_to_win: number) {
        this.size = size;
        this.squares_to_win = squares_to_win;
        this.gameReset();
    }

    // reset boardy, na rade je hrac X
    // for loop pre rozne rozmery hracej plochy
    public gameReset(): void {
        this.win_coords_x = null;
        this.win_coords_y = null;
        this.win_line_code = null;
        this.last_cpu_move = null;
        this.player = "X";
        this.playboard = Array(this.size);
        for (var row = 0; row < this.size; row++) {
            this.playboard[row] = Array(this.size).fill(null);
        }
    }

    // vracia aktualny stav hracej plochy (2d pole)
    public getBoard(): any {
        return this.playboard;
    }

    // kontrola remizy, ak je nejake pole este nevyplnene, vrati false
    // prerobit pre rozne 'size' hodnoty
    private checkTie(): boolean {
        for (let r = 0; r < this.size; r++) {
            for (let c = 0; c < this.size; c++) {
                if (!this.playboard[r][c]) {
                    return false;
                }
            }
        }
        return true;
    }

    // vrati string s oznacenim hraca, null ak sa este nedohralo
    // 
    private checkLine(row: number, col: number) {
        // horizontal line: ensure columns don't overflow
        if (col + this.squares_to_win > this.size) {
            return null;
        }

        let tmp = Array(this.squares_to_win);
        for (let i = 0; i < this.squares_to_win; i++) {

            tmp[i] = this.playboard[row][col+i];

        }
        if (tmp.includes(null)) {
            return null;
        } else {

            let first = tmp[0];
            for (let i = 0; i < this.squares_to_win; i++) {
                if (tmp[i] !== first) {
                    return null;
                }
            }
            return first;

        }

    }

    private checkColumn(row: number, col: number) {
        // vertical column: ensure rows don't overflow
        if (row + this.squares_to_win > this.size) {
            return null;
        }

        let tmp = Array(this.squares_to_win);
        for (let i = 0; i < this.squares_to_win; i++) {

            tmp[i] = this.playboard[row+i][col];

        }
        if (tmp.includes(null)) {
            return null;
        } else {

            let first = tmp[0];
            for (let i = 0; i < this.squares_to_win; i++) {
                if (tmp[i] !== first) {
                    return null;
                }
            }
            return first;

        }

    }

    private checkDiagonalUp(row: number, col: number) {
        // diagonal going up-right: check column and row bounds
        if (col + this.squares_to_win > this.size) {
            return null;
        }
        // need to ensure row - (k-1) >= 0
        if (row - (this.squares_to_win - 1) < 0 ) {
            return null;
        }


        let tmp = Array(this.squares_to_win);
        for (let i = 0; i < this.squares_to_win; i++) {

            tmp[i] = this.playboard[row-i][col+i];

        }
        if (tmp.includes(null)) {
            return null;
        } else {

            let first = tmp[0];
            for (let i = 0; i < this.squares_to_win; i++) {
                if (tmp[i] !== first) {
                    return null;
                }
            }
            return first;

        }   

    }

    private checkDiagonalDown(row: number, col: number) {

        if (col + this.squares_to_win > this.size) {
            return null;
        }

        if (row + this.squares_to_win > this.size ) {
            return null;
        }


        let tmp = Array(this.squares_to_win);
        for (let i = 0; i < this.squares_to_win; i++) {

            tmp[i] = this.playboard[row+i][col+i];

        }
        if (tmp.includes(null)) {
            return null;
        } else {

            let first = tmp[0];
            for (let i = 0; i < this.squares_to_win; i++) {
                if (tmp[i] !== first) {
                    return null;
                }
            }
            return first;

        }   

    }

    private set_win_coords(x: number, y: number, winState: string | null, lineCode: string): string | null {
        if (winState == null) return null;

        this.win_coords_x = x;
        this.win_coords_y = y;
        this.win_line_code = lineCode;
        console.log(`Win coords set to x: ${x}, y: ${y}, lineCode: ${lineCode}`);   

        this.mark_winning_squares();
        return winState;
    }

    private mark_square(val: string | null) {
        if (val == null) {
            return null;
        } else {
            if (val === "X") {
                return "x";
            } else {
                return "o";
            }
        }
    }

    private mark_winning_squares() {
        if (this.win_coords_x == null || this.win_coords_y == null || this.win_line_code == null) {
            return;
        }
        console.log(`Marking winning squares for lineCode: ${this.win_line_code}`);
        if (this.win_line_code === "line") {
            for (let i = 0; i < this.squares_to_win; i++) {
                this.playboard[this.win_coords_x][this.win_coords_y + i] = this.mark_square(this.playboard[this.win_coords_x][this.win_coords_y + i]);
            }
        } else if (this.win_line_code === "column") {
            for (let i = 0; i < this.squares_to_win; i++) {
                this.playboard[this.win_coords_x + i][this.win_coords_y] = this.mark_square(this.playboard[this.win_coords_x + i][this.win_coords_y]);
            }
        } else if (this.win_line_code === "diagonalDown") {
            for (let i = 0; i < this.squares_to_win; i++) {
                this.playboard[this.win_coords_x + i][this.win_coords_y + i] = this.mark_square(this.playboard[this.win_coords_x + i][this.win_coords_y + i]);
            }
        } else if (this.win_line_code === "diagonalUp") {
            for (let i = 0; i < this.squares_to_win; i++) {
                this.playboard[this.win_coords_x - i][this.win_coords_y + i] = this.mark_square(this.playboard[this.win_coords_x - i][this.win_coords_y + i]);
            }
        }
    }

    private checkWinner(): string|null {

        let tmp = null;
        for (let i = 0; i < this.size; i++) {
            for (let j = 0; j < this.size; j++) {

                tmp = this.checkLine(i, j);
                if (tmp) return this.set_win_coords(i, j, tmp, "line");

                tmp = this.checkColumn(i,j);
                if (tmp) return this.set_win_coords(i, j, tmp, "column");

                tmp = this.checkDiagonalDown(i, j);
                if (tmp) return this.set_win_coords(i, j, tmp, "diagonalDown");

                tmp = this.checkDiagonalUp(i,j);
                if (tmp) return this.set_win_coords(i, j, tmp, "diagonalUp");

            }
            
        }
        tmp = this.checkTie() ? "tie" : null;
        
        return tmp;
        
    }

    // po kazdom oznaceni policka na hracej ploche by sa mala volat tato funkcia
    public makeMove(row: number, col: number): string|null  {

        if (!this.playboard[row][col]) {

            this.playboard[row][col] = this.player;

            if (this.player === "X") {
                this.player = "O";
            } else {
                this.player = "X";
            }
        }
        
        let ret = this.checkWinner();
        if (this.cpu_opponent && ret === null && this.player === "O") {
            this.makeCpuMove();
            ret = this.checkWinner();
        }
        return ret;
    }

    private makeCpuMove(): void {
        let emptySquares: Array<{row: number, col: number}> = [];
        for (let r = 0; r < this.size; r++) {
            for (let c = 0; c < this.size; c++) {
                if (!this.playboard[r][c]) {
                    emptySquares.push({row: r, col: c});
                }
            }
        }
        if (emptySquares.length > 0) {
            let choice = emptySquares[Math.floor(Math.random() * emptySquares.length)];
            this.playboard[choice.row][choice.col] = "O";
            this.last_cpu_move = {row: choice.row, col: choice.col};
            this.player = "X";
        }
    }
}