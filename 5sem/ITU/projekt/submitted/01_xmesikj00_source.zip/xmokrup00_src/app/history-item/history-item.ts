import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';

@Component({
  selector: 'app-history-item',
  imports: [CommonModule, MatCardModule],
  templateUrl: './history-item.html',
  styleUrl: './history-item.scss'
})
export class HistoryItem {

  @Input() value: {index: number, player: 'X' | 'O', row: number, col: number} | null = null;

}
