import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HistoryItem } from '../history-item/history-item';

@Component({
  selector: 'app-history-table',
  imports: [CommonModule, HistoryItem],
  templateUrl: './history-table.html',
  styleUrl: './history-table.scss'
})
export class HistoryTable {
  history!: any[];
  step: number = 0;

  @Input() size: number = 1;
  @Input() toggle: boolean = false;

  onOninputChange() {
    // this.clearHistory();
    this.history = Array(this.size).fill(null);
  }

  constructor() {
    this.history = Array(this.size).fill(null);
  }
  ngOnInit() {
    this.clearHistory();
  }

  makeMoveHistory(player: string, row: number, col: number) {
    const move = { index: this.step + 1, player, row: row + 1, col: col + 1 };
    
    this.history[this.step] = move;
    this.step++;
  }

  clearHistory() {
    this.history.fill(null);
    this.step = 0;
  }
}
