import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SquareTable } from './square-table';

describe('SquareTable', () => {
  let component: SquareTable;
  let fixture: ComponentFixture<SquareTable>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SquareTable]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SquareTable);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
