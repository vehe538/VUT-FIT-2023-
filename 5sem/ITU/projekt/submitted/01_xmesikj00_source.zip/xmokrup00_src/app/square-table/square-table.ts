import { Component, OnInit, ViewChild, HostListener, ElementRef, AfterViewInit } from '@angular/core';
import { Square } from '../square/square';
import { CommonModule } from '@angular/common';
import { piskvorky } from '../backend/customAPI';
import { MatButtonModule as matButton } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { HistoryTable } from '../history-table/history-table';
import {MatSliderModule} from '@angular/material/slider';
import { FormsModule } from '@angular/forms';
import {MatCardModule} from '@angular/material/card';


@Component({
  selector: 'app-square-table',
  standalone: true,
  imports: [Square, CommonModule, matButton, MatIconModule, MatTooltipModule, HistoryTable, MatSliderModule, FormsModule, MatCardModule],
  templateUrl: './square-table.html',
  styleUrls: ['./square-table.scss']
})
export class SquareTable {
  game!: piskvorky;
  squares!: any[];
  Outcome: string|null = null;
  Xscore: number = 0;
  Oscore: number = 0;
  Drawscore: number = 0;

  sizeSlider: number = 4;
  squareSlider: number = 3;

  toggleHistory: boolean = true;  
  toggleSettings: boolean = false;
  
  boardScale: number = 1;

  toggleHistoryButton() {
    this.toggleHistory = !this.toggleHistory;
  }

  toggleSettingsButton() {
    this.toggleSettings = !this.toggleSettings;
  }

  toggleCpuOpponentButton() {
    this.game.cpu_opponent = !this.game.cpu_opponent;
  }

  constructor() {
    this.game = new piskvorky(this.sizeSlider, 3);
  }
  
  ngOnInit() {
    this.game.gameReset();
    this.Outcome = null;
    this.squares = this.game.getBoard();
  }
  
  ngAfterViewInit(): void {
  }
  
  @ViewChild('child') child!: HistoryTable;

  resetGame() {
    this.game.gameReset();
    this.Outcome = null;
    this.squares = this.game.getBoard();
    if (this.child && typeof this.child.clearHistory === 'function') {
      this.child.clearHistory();
    }

  }

  
  
  makeMove(indexX: number, indexY: number) {
    if (this.Outcome !== null) return;
    
    const tmp = this.game.player;
    this.Outcome = this.game.makeMove(indexX, indexY);
    if (this.Outcome === "X") {
      this.Xscore += 1;
    } else if (this.Outcome === "O") {
      this.Oscore += 1;
    } else if (this.Outcome === "tie") {
      this.Drawscore += 1;
    }
    if (tmp !== this.game.player && !this.game.cpu_opponent) {
      this.child.makeMoveHistory(tmp, indexX, indexY);
    }

    if (this.game.cpu_opponent) {
      if (this.game.cpu_opponent && this.Outcome === null) {
        this.child.makeMoveHistory("X", indexX, indexY);
        this.child.makeMoveHistory("O", this.game.last_cpu_move!.row, this.game.last_cpu_move!.col);
      } else if (this.game.cpu_opponent && this.Outcome === "O") {
        this.child.makeMoveHistory("X", indexX, indexY);
        this.child.makeMoveHistory("O", this.game.last_cpu_move!.row, this.game.last_cpu_move!.col);
      } else if (this.game.cpu_opponent && this.Outcome === "X") {
        this.child.makeMoveHistory("X", indexX, indexY);
      } else if (this.game.cpu_opponent && this.Outcome === "tie") {
        if (tmp === "X") {
          this.child.makeMoveHistory("X", indexX, indexY);
        } else {
          this.child.makeMoveHistory("X", indexX, indexY);
          this.child.makeMoveHistory("O", this.game.last_cpu_move!.row, this.game.last_cpu_move!.col);
        }
      }
    }
  }

  resetScore() {
    if (confirm("Are you sure you want to reset the score?")) {
      this.Xscore = 0;
      this.Oscore = 0;
      this.Drawscore = 0;
    }
  }
  
  changeSettings() {
    this.game = new piskvorky(this.sizeSlider, this.squareSlider);
    this.resetGame();
  }


}
