import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule as matButton } from '@angular/material/button';

@Component({
  selector: 'app-square',
  imports: [matButton, CommonModule],
  template: `
    <button mat-fab [ngClass]="{
      'x-button': value === 'X',
      'o-button': value === 'O',
      'win-button': value === 'x' || value === 'o',
      'default-button': !value
    }"> {{ value?.toUpperCase() || '&nbsp;' }} </button>
  `,
  styles: ['button { width: 100%; height: 100%; font-size: 5em !important; min-width: 100px; min-height: 100px; }']
})
export class Square {

  @Input() value: string | null = null;


}
