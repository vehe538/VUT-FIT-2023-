Author: Daniel Pernicka (xpernid00)

<script setup lang="ts">
import PiskvorkyGame from './components/PiskvorkyGame.vue'
import { useThemeStore } from './components/store/themeStore'

const themeStore = useThemeStore()
</script>

<template>
  <PiskvorkyGame />
</template>

<style>
:root {
  --theme-bg: #C7C9AC;
  --theme-symbol-o: #3498db;
  --theme-symbol-x: #e74c3c;
  --theme-lines: #2D2D2D;
  --theme-button-bg: #2D2D2D;
  --theme-button-text: #FFFFFF;
  --theme-score-bg: #90A38B;
  --theme-cell-bg: transparent;
  --scrollbar-track: color-mix(in srgb, var(--theme-bg) 20%, transparent);
  --scrollbar-thumb: color-mix(in srgb, var(--theme-lines) 40%, transparent);
  --scrollbar-thumb-hover: color-mix(in srgb, var(--theme-lines) 60%, transparent);
  --scrollbar-thumb-active: color-mix(in srgb, var(--theme-lines) 80%, transparent);
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  background: var(--theme-bg) !important;
  font-family: 'Inter', sans-serif;
  transition: background-color 0.3s ease;
  min-height: 100vh;
  overflow-y: auto;
  overflow-x: hidden;
}

#app {
  min-height: 100vh;
  background: var(--theme-bg);
  transition: background-color 0.3s ease;
}

*::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}

*::-webkit-scrollbar-track {
  background: var(--scrollbar-track);
  border-radius: 5px;
}

*::-webkit-scrollbar-thumb {
  background: var(--scrollbar-thumb);
  border-radius: 5px;
  border: 2px solid transparent;
  background-clip: padding-box;
  transition: background-color 0.2s ease;
}

*::-webkit-scrollbar-thumb:hover {
  background: var(--scrollbar-thumb-hover);
  background-clip: padding-box;
}

*::-webkit-scrollbar-thumb:active {
  background: var(--scrollbar-thumb-active);
  background-clip: padding-box;
}

*::-webkit-scrollbar-corner {
  background: transparent;
}

* {
  scrollbar-width: thin;
  scrollbar-color: var(--scrollbar-thumb) var(--scrollbar-track);
}

.dialog-content::-webkit-scrollbar {
  width: 8px;
}

.dialog-content::-webkit-scrollbar-track {
  background: color-mix(in srgb, var(--theme-score-bg) 20%, transparent);
  border-radius: 4px;
  margin: 5px 0;
}

.dialog-content::-webkit-scrollbar-thumb {
  background: color-mix(in srgb, var(--theme-lines) 40%, transparent);
  border-radius: 4px;
  border: 1px solid transparent;
  background-clip: padding-box;
}

.dialog-content::-webkit-scrollbar-thumb:hover {
  background: color-mix(in srgb, var(--theme-lines) 60%, transparent);
  background-clip: padding-box;
}

@media (prefers-reduced-motion: no-preference) {
  *::-webkit-scrollbar-thumb {
    transition: background-color 0.3s ease, transform 0.2s ease;
  }
  
  *::-webkit-scrollbar-thumb:hover {
    transform: scaleY(1.1);
  }
}

@media (max-width: 768px) {
  *::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }
}

@media (max-width: 480px) {
  *::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }
  
  *::-webkit-scrollbar-thumb {
    border-width: 1px;
  }
}
</style>
