// Theme interface
export interface ColorTheme {
  id: string;
  name: string;
  colors: {
    symbolO: string;
    background: string;
    symbolX: string;
    lines: string;
    buttonBg: string;
    buttonText: string;
    scoreBg: string;
    cellBg: string;
  };
}

// Utility functions for themes
export const getQuarterCirclePath = (
  quarter: number, 
  radius: number = 40, 
  center: number = 50
): string => {
  const angleStart = (quarter - 1) * 90;
  const angleEnd = quarter * 90;
  
  const startRad = (angleStart * Math.PI) / 180;
  const endRad = (angleEnd * Math.PI) / 180;
  
  const startX = center + radius * Math.cos(startRad);
  const startY = center + radius * Math.sin(startRad);
  const endX = center + radius * Math.cos(endRad);
  const endY = center + radius * Math.sin(endRad);
  
  const largeArcFlag = angleEnd - angleStart <= 180 ? "0" : "1";
  
  return `M ${center} ${center} L ${startX} ${startY} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${endX} ${endY} Z`;
};

export const getThemeQuarterColor = (
  theme: ColorTheme, 
  quarter: number
): string => {
  switch (quarter) {
    case 1: return theme.colors.symbolO;
    case 2: return theme.colors.background;
    case 3: return theme.colors.symbolX;
    case 4: return theme.colors.lines;
    default: return '#FFFFFF';
  }
};

// Main game class
export class Piskvorky {
  public playboard: any[][];
  public player: string;
  public winningCells: {row: number, col: number}[] | null;
  public winner: string | null;
  public xWins: number;
  public oWins: number;
  public ties: number;
  public size: number;
  public squares_to_win: number;
  public cpu_opponent: boolean = false;
  public last_cpu_move: {row: number, col: number} | null = null;
  public startingSymbol: string = "X";
  public previousWinner: string | null = null;

  constructor(size: number = 3, squares_to_win: number = 3) {
    this.size = size;
    this.squares_to_win = squares_to_win;
    this.player = this.startingSymbol;
    this.winningCells = null;
    this.winner = null;
    this.previousWinner = null;
    this.xWins = 0;
    this.oWins = 0;
    this.ties = 0;
    this.playboard = Array(this.size);
    for (let row = 0; row < this.size; row++) {
      this.playboard[row] = Array(this.size).fill(null);
    }
    this.gameReset();
  }

  // reset boardy, na rade je starting symbol
  public gameReset(): void {
    // In PvAI mode player is always first
    if (this.cpu_opponent) {
      this.player = this.startingSymbol;
    } else {
      // Use previous winner is starting in PVP mode
      if (this.previousWinner && this.previousWinner !== 'tie') {
        this.player = this.previousWinner;
        this.startingSymbol = this.previousWinner;
      } else {
        this.player = this.startingSymbol;
      }
    }
    
    this.playboard = Array(this.size);
    for (let row = 0; row < this.size; row++) {
      this.playboard[row] = Array(this.size).fill(null);
    }
    this.winningCells = null;
    this.winner = null;
    this.last_cpu_move = null;
  }

  // vracia aktualny stav hracej plochy (2d pole)
  public getBoard(): any {
    return this.playboard;
  }

  // vracia winning cells
  public getWinningCells(): {row: number, col: number}[] | null {
    return this.winningCells;
  }

  // vracia winner info
  public getWinner(): string | null {
    return this.winner;
  }

  // vracia aktualneho hraca
  public getCurrentPlayer(): string {
    return this.player;
  }

  // vracia score
  public getScore(): { xWins: number, oWins: number, ties: number } {
    return {
      xWins: this.xWins,
      oWins: this.oWins,
      ties: this.ties
    };
  }

  // Set the starting symbol
  public setStartingSymbol(symbol: string): void {
    if (symbol === "X" || symbol === "O") {
      this.startingSymbol = symbol;
      // When AI is enabled, don't reset previousWinner
      if (!this.cpu_opponent) {
        this.previousWinner = null;
      }
      // If no previous game exists, set default
      if (this.winner === null) {
        this.player = symbol;
      }
    } else {
      console.warn("Starting symbol must be either 'X' or 'O'");
    }
  }

  // Get the current starting symbol
  public getStartingSymbol(): string {
    return this.startingSymbol;
  }

  // Enable/disable CPU opponent
  public setCpuOpponent(enabled: boolean): void {
    this.cpu_opponent = enabled;
    // When enabling AI, reset game
    if (enabled) {
      this.gameReset();
    }
  }

  // Set size and winning length
  setSize(size: number) {
    this.size = size;
    this.squares_to_win = Math.min(this.squares_to_win, size); // Ensure winning length capped at size
    this.gameReset(); // Reset the game with new size
  }
  
  setWinningLength(length: number) {
    if (length >= 3 && length <= this.size) {
      this.squares_to_win = length;
    }
  }

  // Board size and styling calculations
  public getBoardSizePixels(containerWidth: number, containerHeight: number): number {
    const maxSize = Math.min(containerWidth, containerHeight);
    const minSize = Math.min(300, maxSize);
    let size = Math.max(minSize, maxSize - 60);
    
    if (size < 200) {
      size = 200;
    }
    
    return size;
  }

  public getCellFontSize(boardSizePx: number): string {
    const baseSize = boardSizePx / this.size;
    return `${Math.max(16, baseSize * 0.6)}px`;
  }

  public getCellBorderThickness(boardSizePx: number): number {
    const baseSize = boardSizePx / this.size;
    let borderThickness = Math.max(1, baseSize * 0.02);
    
    if (this.size > 10) {
      borderThickness = Math.max(0.5, baseSize * 0.015);
    }
    
    if (this.size <= 4) {
      borderThickness = Math.max(2, baseSize * 0.03);
    }
    
    return Math.min(borderThickness, 3);
  }

  public getWinningLineThickness(boardSizePx: number): number {
    const cellBorderThickness = this.getCellBorderThickness(boardSizePx);
    const lineThickness = cellBorderThickness * 3;
    return Math.min(Math.max(lineThickness, 3), 8);
  }

  public getWinningLineSegments(): Array<{
    left: string;
    top: string;
    width: string;
    transform: string;
  }> | null {
    if (!this.winningCells || this.winningCells.length < 2) return null;
    
    const segments = [];
    const cellSize = 100 / this.size;
    
    for (let i = 0; i < this.winningCells.length - 1; i++) {
      const current = this.winningCells[i];
      const next = this.winningCells[i + 1];
      
      const currentX = (current.col + 0.5) * cellSize;
      const currentY = (current.row + 0.5) * cellSize;
      const nextX = (next.col + 0.5) * cellSize;
      const nextY = (next.row + 0.5) * cellSize;
      
      const length = Math.sqrt(Math.pow(nextX - currentX, 2) + Math.pow(nextY - currentY, 2));
      const angle = Math.atan2(nextY - currentY, nextX - currentX) * 180 / Math.PI;
      const centerX = (currentX + nextX) / 2;
      const centerY = (currentY + nextY) / 2;
      
      segments.push({
        left: `${centerX}%`,
        top: `${centerY}%`,
        width: `${length}%`,
        transform: `translate(-50%, -50%) rotate(${angle}deg)`
      });
    }
    
    return segments;
  }

  // Validation methods
  public validateBoardSize(size: number): { valid: boolean; message?: string } {
    if (size < 3) {
      return { valid: false, message: "Board size must be at least 3" };
    }
    if (size > 99) {
      return { valid: false, message: "Board size cannot exceed 99" };
    }
    return { valid: true };
  }

  public validateWinningLength(length: number): { valid: boolean; message?: string } {
    if (length < 3) {
      return { valid: false, message: "Winning length must be at least 3" };
    }
    if (length > this.size) {
      return { valid: false, message: `Winning length cannot exceed board size (${this.size})` };
    }
    return { valid: true };
  }

  public canMakeMove(row: number, col: number): boolean {
    if (this.isGameFinished()) {
      return false; // Game is finished, cannot make moves
    }
    
    if (row < 0 || row >= this.size || col < 0 || col >= this.size) {
      return false; // Out of bounds
    }
    
    if (this.playboard[row][col]) {
      return false; // Cell already occupied
    }
    
    // Ensure playr doesnt paly on CPU turn
    if (this.cpu_opponent && this.player !== this.startingSymbol) {
      return false;
    }
    
    return true;
  }

  // kontrola remizy, ak je nejake pole este nevyplnene, vrati false
  private checkTie(): boolean {
    for (let r = 0; r < this.size; r++) {
      for (let c = 0; c < this.size; c++) {
        if (!this.playboard[r][c]) {
          return false;
        }
      }
    }
    return true;
  }

  // Check if all elements in array are the same and not null
  private checkLineForWin(line: any[]): string | null {
    if (line.includes(null)) {
      return null;
    }
    
    const first = line[0];
    for (let i = 1; i < line.length; i++) {
      if (line[i] !== first) {
        return null;
      }
    }
    return first;
  }

  // kontrola riadkov
  private checkLine(row: number, col: number): string | null {
    if (col + this.squares_to_win > this.size) {
      return null;
    }

    const tmp = Array(this.squares_to_win);
    for (let i = 0; i < this.squares_to_win; i++) {
      tmp[i] = this.playboard[row][col + i];
    }

    const result = this.checkLineForWin(tmp);
    if (result) {
      this.winningCells = [];
      for (let i = 0; i < this.squares_to_win; i++) {
        this.winningCells.push({row, col: col + i});
      }
    }
    return result;
  }

  // Kontrola stlpcov
  private checkColumn(row: number, col: number): string | null {
    if (row + this.squares_to_win > this.size) {
      return null;
    }

    const tmp = Array(this.squares_to_win);
    for (let i = 0; i < this.squares_to_win; i++) {
      tmp[i] = this.playboard[row + i][col];
    }

    const result = this.checkLineForWin(tmp);
    if (result) {
      this.winningCells = [];
      for (let i = 0; i < this.squares_to_win; i++) {
        this.winningCells.push({row: row + i, col});
      }
    }
    return result;
  }

  // Check diagonal (top-left to bottom-right)
  private checkDiagonalDown(row: number, col: number): string | null {
    if (col + this.squares_to_win > this.size || row + this.squares_to_win > this.size) {
      return null;
    }

    const tmp = Array(this.squares_to_win);
    for (let i = 0; i < this.squares_to_win; i++) {
      tmp[i] = this.playboard[row + i][col + i];
    }

    const result = this.checkLineForWin(tmp);
    if (result) {
      this.winningCells = [];
      for (let i = 0; i < this.squares_to_win; i++) {
        this.winningCells.push({row: row + i, col: col + i});
      }
    }
    return result;
  }

  // Check diagonal (bottom-left to top-right)
  private checkDiagonalUp(row: number, col: number): string | null {
    if (col + this.squares_to_win > this.size || row - this.squares_to_win < -1) {
      return null;
    }

    const tmp = Array(this.squares_to_win);
    for (let i = 0; i < this.squares_to_win; i++) {
      tmp[i] = this.playboard[row - i][col + i];
    }

    const result = this.checkLineForWin(tmp);
    if (result) {
      this.winningCells = [];
      for (let i = 0; i < this.squares_to_win; i++) {
        this.winningCells.push({row: row - i, col: col + i});
      }
    }
    return result;
  }

  // Winner checking
  private checkWinner(): string | null {
    this.winningCells = null;

    // 3x3 board uses optimized original checking
    if (this.size === 3 && this.squares_to_win === 3) {
      // Check rows
      for (let i = 0; i < 3; i++) {
        if (this.playboard[i][0] && (this.playboard[i][0] === this.playboard[i][1] && this.playboard[i][0] === this.playboard[i][2])) {
          this.winningCells = [
            {row: i, col: 0},
            {row: i, col: 1},
            {row: i, col: 2}
          ];
          return this.playboard[i][0];
        }
      }

      // Check columns
      for (let i = 0; i < 3; i++) {
        if (this.playboard[0][i] && (this.playboard[0][i] === this.playboard[1][i] && this.playboard[0][i] === this.playboard[2][i])) {
          this.winningCells = [
            {row: 0, col: i},
            {row: 1, col: i},
            {row: 2, col: i}
          ];
          return this.playboard[0][i];
        }
      }

      // Check diagonals
      if (this.playboard[0][0] && (this.playboard[0][0] === this.playboard[1][1] && this.playboard[0][0] === this.playboard[2][2])) {
        this.winningCells = [
          {row: 0, col: 0},
          {row: 1, col: 1},
          {row: 2, col: 2}
        ];
        return this.playboard[0][0];
      }

      if (this.playboard[0][2] && (this.playboard[0][2] === this.playboard[1][1] && this.playboard[0][2] === this.playboard[2][0])) {
        this.winningCells = [
          {row: 0, col: 2},
          {row: 1, col: 1},
          {row: 2, col: 0}
        ];
        return this.playboard[0][2];
      }
    } else {
      // General new checking for non-standard games
      for (let i = 0; i < this.size; i++) {
        for (let j = 0; j < this.size; j++) {
          let tmp = this.checkLine(i, j);
          if (tmp) return tmp;

          tmp = this.checkColumn(i, j);
          if (tmp) return tmp;

          tmp = this.checkDiagonalDown(i, j);
          if (tmp) return tmp;

          tmp = this.checkDiagonalUp(i, j);
          if (tmp) return tmp;
        }
      }
    }

    if (this.checkTie()) {
      return "tie";
    }
    return null;
  }

  // Check if cell is part of winning line
  public isWinningCell(row: number, col: number): boolean {
    if (!this.winningCells) return false;
    
    return this.winningCells.some(cell => cell.row === row && cell.col === col);
  }

  // Check if game is finished
  public isGameFinished(): boolean {
    return this.winner !== null;
  }

  // Get cell display value
  public getCellDisplay(cell: string | null | undefined): string {
    return cell ?? '';
  }

  // CPU move function
  private makeCpuMove(): void {
    let emptySquares: Array<{row: number, col: number}> = [];
    const cpuSymbol = this.startingSymbol === "X" ? "O" : "X"; // CPU always uses opposite symbol
    
    for (let r = 0; r < this.size; r++) {
      for (let c = 0; c < this.size; c++) {
        if (!this.playboard[r][c]) {
          emptySquares.push({row: r, col: c});
        }
      }
    }
    if (emptySquares.length > 0) {
      let choice = emptySquares[Math.floor(Math.random() * emptySquares.length)];
      this.playboard[choice.row][choice.col] = cpuSymbol;
      this.last_cpu_move = {row: choice.row, col: choice.col};
      this.player = this.startingSymbol;
    }
  }

  // Main move function
  public makeMove(row: number, col: number): void {
    // If game is finished, reset when clicking anywhere on the board
    if (this.isGameFinished()) {
      this.gameReset();
      return;
    }
    
    // Only make move if cell is empty
    if (!this.playboard[row][col]) {
      this.playboard[row][col] = this.player;
      console.log("marked ", row, col, "as ", this.player);

      const result = this.checkWinner();
      
      if (result !== null) {
        this.winner = result;
        
        // When AI is disabled, store winner for next round
        if (!this.cpu_opponent) {
          if (result !== 'tie') {
            this.previousWinner = result;
          } else {
            this.previousWinner = null; // Reset for tie games
          }
        }
        
        if (result === 'tie') {
          this.ties++;
        } else if (result === 'X') {
          this.xWins++;
        } else if (result === 'O') {
          this.oWins++;
        }
      } else {
        // When AI is enabled, don't switch player
        if (this.cpu_opponent) {
          this.makeCpuMove();
          
          // Check for winner after CPU move
          const cpuResult = this.checkWinner();
          if (cpuResult !== null) {
            this.winner = cpuResult;
            
            if (cpuResult === 'tie') {
              this.ties++;
            } else if (cpuResult === 'X') {
              this.xWins++;
            } else if (cpuResult === 'O') {
              this.oWins++;
            }
          }
        } else {
          // No AI, switch normally
          this.player = this.player === "X" ? "O" : "X";
        }
      }
    }
  }
}
