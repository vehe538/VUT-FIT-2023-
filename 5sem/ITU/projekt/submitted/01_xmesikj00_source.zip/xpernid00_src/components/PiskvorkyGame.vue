Author: Daniel Pernicka (xpernid00)

<script setup lang="ts">
import { reactive, ref } from 'vue'
import { Piskvorky } from '../api/customAPI'
import GameBoard from './gameBoard.vue'
import ScoreCard from './scoreCard.vue'
import SettingsDialog from './settingsDialog.vue'
import RulesDialog from './rulesDialog.vue'
import CustomizationDialog from './customizationDialog.vue'
import ModeDialog from './modeDialog.vue'

const game = reactive(new Piskvorky())
const showSettingsDialog = ref(false)
const showRulesDialog = ref(false)
const showCustomizationDialog = ref(false)
const showModeDialog = ref(false)
const isPvP = ref(true)

const toggleGameMode = () => {
  isPvP.value = !isPvP.value
  game.cpu_opponent = !isPvP.value
  
  if (!isPvP.value) {
    // Set human as starting player
    game.setStartingSymbol("X")
  }
  
  resetGameOnly()
}

const resetGameOnly = () => {
  game.gameReset()
}

const resetEverything = () => {
  game.gameReset()
  game.xWins = 0
  game.oWins = 0
  game.ties = 0
  
  // Reset starting symbol based on mode
  if (game.cpu_opponent) {
    game.setStartingSymbol("X")
  } else {
    game.setStartingSymbol("X")
  }
  
  game.previousWinner = null
}

const changeStartingSymbol = (symbol: string) => {
  game.setStartingSymbol(symbol)
  game.gameReset()
}

const openSettings = () => {
  showSettingsDialog.value = true
}

const closeSettings = () => {
  showSettingsDialog.value = false
}

const openRules = () => {
  closeSettings()
  showRulesDialog.value = true
}

const closeRules = () => {
  showRulesDialog.value = false
}

const returnFromRulesToSettings = () => {
  closeRules()
  openSettings()
}

const openCustomization = () => {
  closeSettings()
  showCustomizationDialog.value = true
}

const closeCustomization = () => {
  showCustomizationDialog.value = false
}

const returnFromCustomizationToSettings = () => {
  closeCustomization()
  openSettings()
}

const openMode = () => {
  closeSettings()
  showModeDialog.value = true
}

const closeMode = () => {
  showModeDialog.value = false
}

const returnFromModeToSettings = () => {
  closeMode()
  openSettings()
}
</script>

<template>
  <div class="piskvorky-game">
    <button @click="openSettings()" class="settings-btn">
      SETTINGS
    </button>

    <div class="game-container">
      <GameBoard :game="game" />
      <ScoreCard :game="game" />
    </div>

    <button @click="resetEverything()" class="reset-btn">
      NEW GAME
    </button>

    <SettingsDialog
      v-if="showSettingsDialog"
      :open-rules="openRules"
      :open-customization="openCustomization"
      :open-mode="openMode"
      :close-settings="closeSettings"
    />

    <RulesDialog
      v-if="showRulesDialog"
      :game="game"
      :change-starting-symbol="changeStartingSymbol"
      :return-to-settings="returnFromRulesToSettings"
      :close-dialog="closeRules"
    />

    <CustomizationDialog
      v-if="showCustomizationDialog"
      :return-to-settings="returnFromCustomizationToSettings"
      :close-dialog="closeCustomization"
    />

    <ModeDialog
      v-if="showModeDialog"
      :is-pv-p="isPvP"
      :toggle-game-mode="toggleGameMode"
      :return-to-settings="returnFromModeToSettings"
      :close-dialog="closeMode"
    />
  </div>
</template>

<style scoped>
.piskvorky-game {
  min-height: 100vh;
  background: var(--theme-bg);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 20px;
  font-family: 'Inter', sans-serif;
  position: relative;
  transition: background-color 0.3s ease;
}

.game-container {
  background: transparent;
  padding: 40px;
  min-width: 400px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 30px;
}

.settings-btn {
  position: absolute;
  top: 40px;
  right: 40px;
  padding: 15px 40px;
  font-size: 1.1rem;
  font-weight: 600;
  background: var(--theme-button-bg);
  color: var(--theme-button-text);
  border: none;
  border-radius: 25px;
  cursor: pointer;
  transition: all 0.3s ease;
  letter-spacing: 1px;
  text-transform: uppercase;
  font-family: 'Inter', sans-serif;
}

.settings-btn:hover {
  transform: translateY(-2px);
  background: color-mix(in srgb, var(--theme-button-bg) 80%, white);
}

.reset-btn {
  position: absolute;
  bottom: 40px;
  right: 40px;
  padding: 15px 40px;
  font-size: 1.1rem;
  font-weight: 600;
  background: var(--theme-button-bg);
  color: var(--theme-button-text);
  border: none;
  border-radius: 25px;
  cursor: pointer;
  transition: all 0.3s ease;
  letter-spacing: 1px;
  text-transform: uppercase;
  font-family: 'Inter', sans-serif;
}

.reset-btn:hover {
  transform: translateY(-2px);
  background: color-mix(in srgb, var(--theme-button-bg) 80%, white);
}
</style>
