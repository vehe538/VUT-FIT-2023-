Author: Daniel Pernicka (xpernid00)

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useThemeStore } from './store/themeStore'
import { getQuarterCirclePath, type ColorTheme } from '../api/customAPI'

const props = defineProps<{
  returnToSettings: () => void
  closeDialog: () => void
}>()

const themeStore = useThemeStore()
const themes = computed(() => themeStore.themes)
const currentThemeId = ref(themeStore.currentThemeId)

const selectTheme = (themeId: string) => {
  currentThemeId.value = themeId
  themeStore.setTheme(themeId)
  
  const selectedCard = document.querySelector(`[data-theme-id="${themeId}"]`)
  if (selectedCard) {
    selectedCard.classList.add('theme-selected-feedback')
    setTimeout(() => {
      selectedCard.classList.remove('theme-selected-feedback')
    }, 300)
  }
}

const chunkThemes = computed(() => {
  const chunkSize = 3
  const chunks = []
  for (let i = 0; i < themes.value.length; i += chunkSize) {
    chunks.push(themes.value.slice(i, i + chunkSize))
  }
  return chunks
})

const isActiveTheme = (themeId: string): boolean => {
  return themeStore.currentThemeId === themeId
}
</script>

<template>
  <div class="dialog-overlay" @click.self="closeDialog">
    <div class="customization-dialog">
      <div class="dialog-header">
        <button @click="returnToSettings" class="dialog-back-btn">
          <svg class="back-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="15 18 9 12 15 6"></polyline>
          </svg>
          <span class="back-text">Back</span>
        </button>
        
        <button @click="closeDialog" class="dialog-exit-btn">
          <svg class="exit-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>

      <h2 class="dialog-title">Themes</h2>

      <div class="dialog-content">
        <div class="theme-selection">
          <div class="theme-grid-container">
            <div 
              v-for="(row, rowIndex) in chunkThemes" 
              :key="rowIndex"
              class="theme-row"
            >
              <div 
                v-for="theme in row" 
                :key="theme.id"
                :data-theme-id="theme.id"
                class="theme-preview"
                :class="{ 'active': isActiveTheme(theme.id) }"
                @click="selectTheme(theme.id)"
              >
                <div class="theme-preview-circle">
                  <svg 
                    class="theme-mini-circle" 
                    viewBox="0 0 100 100" 
                    width="60" 
                    height="60"
                  >
                    <path 
                      :d="getQuarterCirclePath(1, 40, 50)"
                      :fill="theme.colors.symbolO"
                    />
                    <path 
                      :d="getQuarterCirclePath(2, 40, 50)"
                      :fill="theme.colors.background"
                    />
                    <path 
                      :d="getQuarterCirclePath(3, 40, 50)"
                      :fill="theme.colors.symbolX"
                    />
                    <path 
                      :d="getQuarterCirclePath(4, 40, 50)"
                      :fill="theme.colors.lines"
                    />
                  </svg>
                </div>
                <div class="theme-preview-name">{{ theme.name }}</div>
                <div v-if="isActiveTheme(theme.id)" class="active-badge">
                  <svg class="check-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  <span>Active</span>
                </div>
              </div>
              <div 
                v-for="n in 3 - row.length" 
                :key="`empty-${n}`"
                class="theme-preview empty"
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(4px);
}

.customization-dialog {
  background: var(--theme-bg);
  border-radius: 20px;
  padding: 25px 30px;
  width: 90%;
  max-width: 550px;
  max-height: 85vh;
  position: relative;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  animation: dialogSlideIn 0.3s ease;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

@keyframes dialogSlideIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dialog-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 15px;
  flex-shrink: 0;
}

.dialog-back-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--theme-score-bg);
  border: none;
  border-radius: 25px;
  padding: 10px 20px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-family: 'Inter', sans-serif;
  color: var(--theme-button-text);
  font-weight: 600;
  font-size: 1rem;
}

.dialog-back-btn:hover {
  background: color-mix(in srgb, var(--theme-score-bg) 80%, black);
  transform: translateX(-3px);
}

.back-icon {
  width: 18px;
  height: 18px;
  stroke-width: 2.5;
  stroke: var(--theme-button-text);
}

.back-text {
  margin-top: 2px;
}

.dialog-exit-btn {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: var(--theme-button-bg);
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  flex-shrink: 0;
}

.dialog-exit-btn:hover {
  background: color-mix(in srgb, var(--theme-button-bg) 80%, white);
  transform: rotate(90deg);
}

.exit-icon {
  width: 20px;
  height: 20px;
  color: var(--theme-button-text);
  stroke-width: 2.5;
}

.dialog-title {
  text-align: center;
  color: var(--theme-lines);
  margin-bottom: 15px;
  font-size: 1.8rem;
  font-weight: 700;
  letter-spacing: 1px;
  flex-shrink: 0;
}

.dialog-content {
  color: var(--theme-lines);
  font-size: 1.1rem;
  line-height: 1.6;
  padding: 0 5px;
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow-y: auto;
  overflow-x: hidden;
}

.dialog-content::-webkit-scrollbar {
  width: 8px;
}

.dialog-content::-webkit-scrollbar-track {
  background: color-mix(in srgb, var(--theme-score-bg) 20%, transparent);
  border-radius: 4px;
  margin: 5px 0;
}

.dialog-content::-webkit-scrollbar-thumb {
  background: color-mix(in srgb, var(--theme-lines) 40%, transparent);
  border-radius: 4px;
}

.dialog-content::-webkit-scrollbar-thumb:hover {
  background: color-mix(in srgb, var(--theme-lines) 60%, transparent);
}

.theme-selection {
  width: 100%;
  display: flex;
  flex-direction: column;
  margin-bottom: 10px;
}

.theme-grid-container {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 15px;
  padding: 0 5px;
  margin-bottom: 25px;
}

.theme-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
  width: 100%;
}

.theme-preview {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 15px 10px;
  border-radius: 12px;
  transition: all 0.3s ease;
  background: color-mix(in srgb, var(--theme-score-bg) 20%, transparent);
  border: 2px solid transparent;
  position: relative;
  min-height: 130px;
}

.theme-preview:hover {
  background: color-mix(in srgb, var(--theme-score-bg) 40%, transparent);
  transform: translateY(-3px);
  border-color: color-mix(in srgb, var(--theme-lines) 30%, transparent);
}

.theme-preview.active {
  background: color-mix(in srgb, var(--theme-button-bg) 20%, transparent);
  border-color: var(--theme-button-bg);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
}

.theme-preview.theme-selected-feedback {
  animation: themeSelected 0.3s ease;
}

@keyframes themeSelected {
  0% { transform: scale(1); }
  50% { transform: scale(1.05); }
  100% { transform: scale(1); }
}

.theme-preview.empty {
  opacity: 0;
  pointer-events: none;
  visibility: hidden;
}

.theme-preview-circle {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 6px;
}

.theme-mini-circle {
  filter: drop-shadow(0 2px 6px rgba(0, 0, 0, 0.2));
  border-radius: 50%;
  overflow: hidden;
}

.theme-preview-name {
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--theme-lines);
  text-align: center;
  width: 100%;
  word-wrap: break-word;
  min-height: 2.5em;
  display: flex;
  align-items: center;
  justify-content: center;
}

.active-badge {
  position: absolute;
  top: 8px;
  right: 8px;
  display: flex;
  align-items: center;
  gap: 4px;
  background: var(--theme-button-bg);
  color: var(--theme-button-text);
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 0.7rem;
  font-weight: 600;
  animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
  from { opacity: 0; transform: scale(0.8); }
  to { opacity: 1; transform: scale(1); }
}

.check-icon {
  width: 12px;
  height: 12px;
}

@media (max-width: 768px) {
  .customization-dialog {
    padding: 20px 25px;
    max-height: 80vh;
  }
  
  .dialog-title {
    font-size: 1.6rem;
    margin-bottom: 12px;
  }
  
  .theme-row {
    gap: 10px;
  }
  
  .theme-preview {
    padding: 12px 8px;
    min-height: 120px;
  }
}

@media (max-width: 480px) {
  .customization-dialog {
    padding: 15px 20px;
    max-height: 75vh;
  }
  
  .theme-row {
    gap: 8px;
  }
  
  .theme-preview {
    padding: 10px 6px;
    min-height: 110px;
  }
  
  .theme-mini-circle {
    width: 50px;
    height: 50px;
  }
  
  .dialog-title {
    font-size: 1.5rem;
  }
  
  .theme-preview-name {
    font-size: 0.8rem;
    min-height: 2.2em;
  }
  
  .active-badge {
    font-size: 0.65rem;
    padding: 3px 6px;
  }
  
  .check-icon {
    width: 10px;
    height: 10px;
  }
}

@media (max-width: 380px) {
  .theme-row {
    gap: 6px;
  }
  
  .theme-preview {
    padding: 8px 5px;
    min-height: 100px;
  }
  
  .theme-mini-circle {
    width: 45px;
    height: 45px;
  }
  
  .theme-preview-name {
    font-size: 0.75rem;
  }
}
</style>
