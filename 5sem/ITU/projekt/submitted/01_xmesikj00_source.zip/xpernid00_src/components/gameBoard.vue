Author: Daniel Pernicka (xpernid00)

<script setup lang="ts">
import { computed, ref, onMounted, onUnmounted } from 'vue'
import { useThemeStore } from './store/themeStore'

const props = defineProps<{
  game: {
    size: number;
    getBoard: () => any[][];
    getWinningCells: () => { row: number; col: number }[] | null;
    getWinningLineSegments: () => Array<{
      left: string;
      top: string;
      width: string;
      transform: string;
    }> | null;
    getBoardSizePixels: (containerWidth: number, containerHeight: number) => number;
    getCellFontSize: (boardSizePx: number) => string;
    getCellBorderThickness: (boardSizePx: number) => number;
    getWinningLineThickness: (boardSizePx: number) => number;
    isWinningCell: (row: number, col: number) => boolean;
    isGameFinished: () => boolean;
    getCellDisplay: (cell: string | null | undefined) => string;
    makeMove: (row: number, col: number) => void;
  }
}>()

const themeStore = useThemeStore()
const containerRef = ref<HTMLElement | null>(null)
const boardSizePx = ref(400)

const updateBoardSize = () => {
  if (!containerRef.value) return
  
  const containerWidth = containerRef.value.clientWidth
  const containerHeight = containerRef.value.clientHeight
  boardSizePx.value = props.game.getBoardSizePixels(containerWidth, containerHeight)
}

const gridStyle = computed(() => ({
  display: 'grid',
  gridTemplateRows: `repeat(${props.game.size}, 1fr)`,
  gridTemplateColumns: `repeat(${props.game.size}, 1fr)`,
  width: `${boardSizePx.value}px`,
  height: `${boardSizePx.value}px`,
  position: 'relative',
  zIndex: 1,
}))

const cellFontSize = computed(() => {
  return props.game.getCellFontSize(boardSizePx.value)
})

const cellBorderThickness = computed(() => {
  return props.game.getCellBorderThickness(boardSizePx.value)
})

const winningLineThickness = computed(() => {
  return props.game.getWinningLineThickness(boardSizePx.value)
})

const borderThicknessStyle = computed(() => `${cellBorderThickness.value}px`)
const lineThicknessStyle = computed(() => `${winningLineThickness.value}px`)

const winningLineSegments = computed(() => props.game.getWinningLineSegments())

const makeMove = (row: number, col: number) => {
  props.game.makeMove(row, col)
}

onMounted(() => {
  updateBoardSize()
  window.addEventListener('resize', updateBoardSize)
})

onUnmounted(() => {
  window.removeEventListener('resize', updateBoardSize)
})
</script>

<template>
  <div 
    class="game-board-wrapper" 
    ref="containerRef"
    :class="{ 'game-finished': game.isGameFinished() }"
  >
    <div class="game-board" :style="gridStyle as any">
      <button
        v-for="(cell, index) in game.getBoard().flat()"
        :key="index"
        class="cell"
        :class="{
          'cell-x': cell === 'X',
          'cell-o': cell === 'O',
          'winning-cell': game.isWinningCell(Math.floor(index / game.size), index % game.size)
        }"
        @click="makeMove(Math.floor(index / game.size), index % game.size)"
        :disabled="!!cell && !game.isGameFinished()"
        :style="{ 
          fontSize: cellFontSize,
          borderWidth: borderThicknessStyle 
        }"
      >
        <span class="cell-content">{{ game.getCellDisplay(cell) }}</span>
      </button>
    </div>

    <div v-if="winningLineSegments" class="winning-line-overlay">
      <div 
        v-for="(segment, index) in winningLineSegments" 
        :key="index"
        class="line-segment"
        :style="{
          left: segment.left,
          top: segment.top,
          width: segment.width,
          transform: segment.transform,
          height: lineThicknessStyle
        }"
      ></div>
    </div>
  </div>
</template>

<style scoped>
.game-board-wrapper {
  position: relative;
  background: var(--theme-bg);
  border-radius: 8px;
  padding: 30px;
  width: 100%;
  height: 100%;
  min-width: 300px;
  min-height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  box-sizing: border-box;
}

.game-board-wrapper.game-finished {
  cursor: pointer;
}

.game-board {
  flex-shrink: 0;
  box-sizing: border-box;
  background: var(--theme-bg);
  border-radius: 8px;
  position: relative;
}

.cell {
  border: solid var(--theme-lines);
  background: var(--theme-cell-bg);
  font-weight: 800;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
  font-family: 'Inter', sans-serif;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  min-width: 0;
  min-height: 0;
  aspect-ratio: 1;
  overflow: hidden;
  padding: 2px;
}

.cell:hover:not(:disabled) {
  background: color-mix(in srgb, white 10%, transparent);
}

.cell:disabled {
  cursor: not-allowed;
}

.cell-x {
  color: var(--theme-symbol-x);
}

.cell-o {
  color: var(--theme-symbol-o);
}

.cell-content {
  line-height: 1;
  display: block;
  min-height: 1em;
}

.winning-cell {
  z-index: 2;
  animation: pulse 1s infinite;
}

@keyframes pulse {
  0% { transform: scale(1); }
  50% { transform: scale(1.02); }
  100% { transform: scale(1); }
}

.winning-cell.cell-x {
  color: color-mix(in srgb, var(--theme-symbol-x) 80%, black);
}

.winning-cell.cell-o {
  color: color-mix(in srgb, var(--theme-symbol-o) 80%, black);
}

.winning-line-overlay {
  position: absolute;
  top: 30px;
  left: 30px;
  right: 30px;
  bottom: 30px;
  pointer-events: none;
  z-index: 3;
}

.line-segment {
  position: absolute;
  background: var(--theme-lines);
  transform-origin: center;
}

@media (max-width: 768px) {
  .game-board-wrapper {
    padding: 20px;
    min-width: 250px;
    min-height: 250px;
  }
}

@media (max-width: 480px) {
  .game-board-wrapper {
    padding: 15px;
    min-width: 200px;
    min-height: 200px;
  }
}
</style>
