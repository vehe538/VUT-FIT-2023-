Author: Daniel Pernicka (xpernid00)

<script setup lang="ts">
const props = defineProps<{
  isPvP: boolean
  toggleGameMode: () => void
  returnToSettings: () => void
  closeDialog: () => void
}>()
</script>

<template>
  <div class="dialog-overlay" @click.self="closeDialog">
    <div class="mode-dialog">
      <div class="dialog-header">
        <button @click="returnToSettings" class="dialog-back-btn">
          <svg class="back-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="15 18 9 12 15 6"></polyline>
          </svg>
          <span class="back-text">Back</span>
        </button>
        
        <button @click="closeDialog" class="dialog-exit-btn">
          <svg class="exit-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>

      <h2 class="dialog-title">Game Mode</h2>

      <div class="dialog-content">
        <div class="mode-section">
          <h3 class="section-title">Select Game Mode</h3>
          <div class="mode-toggle-container">            
            <div class="mode-toggle-wrapper">
              <div class="mode-labels">
                <span class="mode-label" :class="{ 'active': isPvP }">PvP</span>
                <span class="mode-label" :class="{ 'active': !isPvP }">PvAI</span>
              </div>
              
              <button 
                class="mode-toggle-btn" 
                @click="toggleGameMode"
                :aria-pressed="!isPvP"
              >
                <div class="toggle-track">
                  <div class="toggle-slider" :class="{ 'ai-mode': !isPvP }">
                    <span class="toggle-text">{{ isPvP ? 'PvP' : 'PvAI' }}</span>
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(4px);
}

.mode-dialog {
  background: var(--theme-bg);
  border-radius: 20px;
  padding: 40px;
  width: 90%;
  max-width: 500px;
  position: relative;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  animation: dialogSlideIn 0.3s ease;
}

@keyframes dialogSlideIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dialog-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 20px;
}

.dialog-back-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--theme-score-bg);
  border: none;
  border-radius: 25px;
  padding: 10px 20px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-family: 'Inter', sans-serif;
  color: var(--theme-button-text);
  font-weight: 600;
  font-size: 1rem;
}

.dialog-back-btn:hover {
  background: color-mix(in srgb, var(--theme-score-bg) 80%, black);
  transform: translateX(-3px);
}

.back-icon {
  width: 18px;
  height: 18px;
  stroke-width: 2.5;
  stroke: var(--theme-button-text);
}

.back-text {
  margin-top: 2px;
}

.dialog-exit-btn {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: var(--theme-button-bg);
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  flex-shrink: 0;
}

.dialog-exit-btn:hover {
  background: color-mix(in srgb, var(--theme-button-bg) 80%, white);
  transform: rotate(90deg);
}

.exit-icon {
  width: 20px;
  height: 20px;
  color: var(--theme-button-text);
  stroke-width: 2.5;
}

.dialog-title {
  text-align: center;
  color: var(--theme-lines);
  margin-bottom: 30px;
  font-size: 2rem;
  font-weight: 700;
  letter-spacing: 1px;
}

.dialog-content {
  color: var(--theme-lines);
  font-size: 1.1rem;
  line-height: 1.6;
  padding: 0 10px;
  max-height: 60vh;
  overflow-y: auto;
}

.mode-section {
  background: color-mix(in srgb, white 20%, transparent);
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 20px;
  text-align: left;
}

.section-title {
  color: var(--theme-lines);
  font-size: 1.3rem;
  font-weight: 700;
  margin-bottom: 12px;
  text-align: left;
}

.mode-toggle-container {
  text-align: center;
}

.mode-toggle-wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
}

.mode-labels {
  display: flex;
  justify-content: space-between;
  width: 100%;
  max-width: 300px;
  margin-bottom: 5px;
}

.mode-label {
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--theme-lines);
  opacity: 0.6;
  transition: all 0.3s ease;
}

.mode-label.active {
  opacity: 1;
  color: var(--theme-lines);
}

.mode-toggle-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0;
  width: 100%;
  max-width: 300px;
}

.toggle-track {
  background: var(--theme-score-bg);
  border-radius: 30px;
  height: 60px;
  position: relative;
  transition: all 0.3s ease;
  overflow: hidden;
  border: 3px solid var(--theme-lines);
}

.toggle-slider {
  position: absolute;
  top: 5px;
  left: 5px;
  width: calc(50% - 10px);
  height: calc(100% - 10px);
  background: var(--theme-button-bg);
  border-radius: 25px;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.toggle-slider.ai-mode {
  left: calc(50% + 5px);
}

.toggle-text {
  color: var(--theme-button-text);
  font-size: 1.2rem;
  font-weight: 700;
  letter-spacing: 0.5px;
}
</style>
