Author: Daniel Pernicka (xpernid00)

<script setup lang="ts">
import { ref } from 'vue'

const props = defineProps<{
  game: {
    getStartingSymbol: () => string;
    size: number;
    squares_to_win: number;
    setSize: (size: number) => void;
    setWinningLength: (length: number) => void;
  }
  changeStartingSymbol: (symbol: string) => void;
  returnToSettings: () => void;
  closeDialog: () => void;
}>()

const boardSize = ref(props.game.size)
const winningLineNumber = ref(props.game.squares_to_win)
const isEditingBoardSize = ref(false)
const boardSizeInput = ref(boardSize.value.toString())

const updateBoardSize = (size: number) => {
  if (size >= 3) {
    boardSize.value = size
    boardSizeInput.value = size.toString()
    props.game.setSize(size)
    
    if (winningLineNumber.value > size) {
      winningLineNumber.value = size
      props.game.setWinningLength(size)
    }
  }
  isEditingBoardSize.value = false
}

const updateWinningLineNumber = (length: number) => {
  if (length >= 3 && length <= boardSize.value) {
    winningLineNumber.value = length
    props.game.setWinningLength(length)
  }
}

const startEditingBoardSize = () => {
  isEditingBoardSize.value = true
  boardSizeInput.value = boardSize.value.toString()
  setTimeout(() => {
    const input = document.querySelector('.size-input') as HTMLInputElement
    if (input) {
      input.focus()
      input.select()
    }
  }, 10)
}

const handleBoardSizeInput = (e: Event) => {
  const input = e.target as HTMLInputElement
  // Only allow numbers
  const value = input.value.replace(/\D/g, '')
  boardSizeInput.value = value
  
  // Min size 3
  if (value.length > 2) {
    boardSizeInput.value = value.slice(0, 2)
  }
}

const submitBoardSize = () => {
  if (boardSizeInput.value === '') {
    boardSizeInput.value = boardSize.value.toString()
    isEditingBoardSize.value = false
    return
  }
  
  const newSize = parseInt(boardSizeInput.value)
  if (newSize >= 3 && newSize <= 99) { // Capped max size
    const squaredSize = Math.floor(newSize)
    updateBoardSize(squaredSize)
  } else {
    // If invalid, revert to current size
    boardSizeInput.value = boardSize.value.toString()
    isEditingBoardSize.value = false
  }
}

const handleBoardSizeKeydown = (e: KeyboardEvent) => {
  if (e.key === 'Enter') {
    submitBoardSize()
  } else if (e.key === 'Escape') {
    boardSizeInput.value = boardSize.value.toString()
    isEditingBoardSize.value = false
  }
}

const handleBoardSizeBlur = () => {
  submitBoardSize()
}
</script>

<template>
  <div class="dialog-overlay" @click.self="closeDialog">
    <div class="rules-dialog">
      <div class="dialog-header">
        <button @click="returnToSettings" class="dialog-back-btn">
          <svg class="back-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="15 18 9 12 15 6"></polyline>
          </svg>
          <span class="back-text">Back</span>
        </button>
        
        <button @click="closeDialog" class="dialog-exit-btn">
          <svg class="exit-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>

      <h2 class="dialog-title">Game Rules</h2>

      <div class="dialog-content">
        <div class="rules-section">
          <h3 class="section-title">Starting Player</h3>            
          <div class="symbol-selection">
            <div class="symbol-options">
              <button 
                class="symbol-option" 
                :class="{ 'selected': game.getStartingSymbol() === 'X' }"
                @click="changeStartingSymbol('X')"
              >
                <span class="symbol-x-large">X</span>
                <span class="symbol-label">X starts</span>
              </button>
              
              <button 
                class="symbol-option" 
                :class="{ 'selected': game.getStartingSymbol() === 'O' }"
                @click="changeStartingSymbol('O')"
              >
                <span class="symbol-o-large">O</span>
                <span class="symbol-label">O starts</span>
              </button>
            </div>
          </div>
        </div>

        <div class="rules-section">
          <h3 class="section-title">Board Size</h3>
          <div class="size-selection">
            <div class="size-controls">
              <button 
                v-if="!isEditingBoardSize"
                class="size-btn"
                :disabled="boardSize <= 3"
                @click="updateBoardSize(boardSize - 1)"
              >
                <svg class="size-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
              </button>
              
              <div 
                class="size-display-container"
                :class="{ 'editing': isEditingBoardSize }"
              >
                <div 
                  v-if="!isEditingBoardSize"
                  class="size-display"
                  @click="startEditingBoardSize"
                >
                  <span class="size-value">{{ boardSize }}×{{ boardSize }}</span>
                </div>
                <input
                  v-else
                  class="size-input"
                  type="text"
                  v-model="boardSizeInput"
                  @input="handleBoardSizeInput"
                  @keydown="handleBoardSizeKeydown"
                  @blur="handleBoardSizeBlur"
                  maxlength="2"
                  pattern="\d*"
                  inputmode="numeric"
                />
              </div>
              
              <button 
                v-if="!isEditingBoardSize"
                class="size-btn"
                @click="updateBoardSize(boardSize + 1)"
              >
                <svg class="size-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                  <line x1="12" y1="5" x2="12" y2="19"></line>
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
              </button>
            </div>
          </div>
        </div>

        <div class="rules-section">
          <h3 class="section-title">Winning Line Length</h3>
          <div class="line-selection">
            <div class="line-controls">
              <button 
                class="line-btn"
                :disabled="winningLineNumber <= 3"
                @click="updateWinningLineNumber(winningLineNumber - 1)"
              >
                <svg class="line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
              </button>
              
              <div class="line-display">
                <span class="line-value">{{ winningLineNumber }} in a row</span>
              </div>
              
              <button 
                class="line-btn"
                :disabled="winningLineNumber >= boardSize"
                @click="updateWinningLineNumber(winningLineNumber + 1)"
              >
                <svg class="line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                  <line x1="12" y1="5" x2="12" y2="19"></line>
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(4px);
}

.rules-dialog {
  background: var(--theme-bg);
  border-radius: 20px;
  padding: 40px;
  width: 90%;
  max-width: 500px;
  position: relative;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  animation: dialogSlideIn 0.3s ease;
}

@keyframes dialogSlideIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.dialog-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 20px;
}

.dialog-back-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--theme-score-bg);
  border: none;
  border-radius: 25px;
  padding: 10px 20px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-family: 'Inter', sans-serif;
  color: var(--theme-button-text);
  font-weight: 600;
  font-size: 1rem;
}

.dialog-back-btn:hover {
  background: color-mix(in srgb, var(--theme-score-bg) 80%, black);
  transform: translateX(-3px);
}

.back-icon {
  width: 18px;
  height: 18px;
  stroke-width: 2.5;
  stroke: var(--theme-button-text);
}

.back-text {
  margin-top: 2px;
}

.dialog-exit-btn {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: var(--theme-button-bg);
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  flex-shrink: 0;
}

.dialog-exit-btn:hover {
  background: color-mix(in srgb, var(--theme-button-bg) 80%, white);
  transform: rotate(90deg);
}

.exit-icon {
  width: 20px;
  height: 20px;
  color: var(--theme-button-text);
  stroke-width: 2.5;
}

.dialog-title {
  text-align: center;
  color: var(--theme-lines);
  margin-bottom: 30px;
  font-size: 2rem;
  font-weight: 700;
  letter-spacing: 1px;
}

.dialog-content {
  color: var(--theme-lines);
  font-size: 1.1rem;
  line-height: 1.6;
  padding: 0 10px;
  max-height: 70vh;
  overflow-y: auto;
}

.rules-section {
  background: color-mix(in srgb, white 20%, transparent);
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 20px;
  text-align: left;
}

.section-title {
  color: var(--theme-lines);
  font-size: 1.3rem;
  font-weight: 700;
  margin-bottom: 12px;
  text-align: left;
}

.symbol-selection {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.symbol-options {
  display: flex;
  gap: 15px;
  justify-content: center;
}

.symbol-option {
  flex: 1;
  background: var(--theme-score-bg);
  border: 2px solid transparent;
  border-radius: 12px;
  padding: 20px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  max-width: 150px;
}

.symbol-option:hover {
  background: color-mix(in srgb, var(--theme-score-bg) 80%, black);
  transform: translateY(-2px);
}

.symbol-option.selected {
  background: var(--theme-button-bg);
  border-color: var(--theme-lines);
}

.symbol-x-large {
  font-size: 2.5rem;
  font-weight: 800;
  color: var(--theme-symbol-x);
}

.symbol-o-large {
  font-size: 2.5rem;
  font-weight: 800;
  color: var(--theme-symbol-o);
}

.symbol-label {
  color: var(--theme-button-text);
  font-weight: 600;
  font-size: 1rem;
}

.symbol-option.selected .symbol-label {
  color: var(--theme-button-text);
}

.size-selection,
.line-selection {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.size-controls {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  transition: all 0.3s ease;
}

.line-controls {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
}

.size-btn,
.line-btn {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: var(--theme-button-bg);
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  flex-shrink: 0;
}

.size-btn:hover:not(:disabled),
.line-btn:hover:not(:disabled) {
  background: color-mix(in srgb, var(--theme-button-bg) 80%, white);
  transform: scale(1.1);
}

.size-btn:disabled,
.line-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.size-icon,
.line-icon {
  width: 20px;
  height: 20px;
  stroke: var(--theme-button-text);
}

.size-display-container {
  min-width: 120px;
  text-align: center;
  position: relative;
}

.size-display-container.editing {
  min-width: 180px;
}

.size-display {
  cursor: pointer;
  transition: all 0.3s ease;
  padding: 10px;
  border-radius: 8px;
  position: relative;
}

.size-display:hover {
  background: color-mix(in srgb, var(--theme-score-bg) 30%, transparent);
  transform: translateY(-2px);
}

.size-value,
.line-value {
  font-size: 1.4rem;
  font-weight: 700;
  color: var(--theme-lines);
}

.line-display {
  min-width: 120px;
  text-align: center;
}

.size-hint {
  font-size: 0.75rem;
  color: var(--theme-button-text);
  opacity: 0.7;
  margin-top: 4px;
  font-weight: 500;
}

.size-input {
  width: 100%;
  font-size: 1.4rem;
  font-weight: 700;
  color: var(--theme-lines);
  background: transparent;
  border: 2px solid var(--theme-lines);
  border-radius: 6px;
  text-align: center;
  padding: 8px;
  font-family: inherit;
  outline: none;
}

.size-input:focus {
  border-color: var(--theme-lines);
  box-shadow: none;
}

@media (max-width: 768px) {
  .rules-dialog {
    padding: 30px;
    max-height: 85vh;
  }
  
  .dialog-title {
    font-size: 1.8rem;
    margin-bottom: 25px;
  }
  
  .section-title {
    font-size: 1.2rem;
  }
  
  .symbol-option {
    padding: 15px;
  }
  
  .symbol-x-large,
  .symbol-o-large {
    font-size: 2rem;
  }
  
  .size-controls,
  .line-controls {
    gap: 15px;
  }
  
  .size-btn,
  .line-btn {
    width: 40px;
    height: 40px;
  }
  
  .size-value,
  .line-value {
    font-size: 1.2rem;
  }
  
  .size-hint {
    font-size: 0.7rem;
  }
  
  .size-input {
    font-size: 1.2rem;
    padding: 6px;
  }
  
  .size-display-container.editing {
    min-width: 150px;
  }
}

@media (max-width: 480px) {
  .rules-dialog {
    padding: 20px;
    max-height: 90vh;
  }
  
  .dialog-title {
    font-size: 1.6rem;
    margin-bottom: 20px;
  }
  
  .rules-section {
    padding: 15px;
    margin-bottom: 15px;
  }
  
  .symbol-options {
    gap: 10px;
  }
  
  .symbol-option {
    padding: 12px;
    max-width: 130px;
  }
  
  .symbol-x-large,
  .symbol-o-large {
    font-size: 1.8rem;
  }
  
  .size-controls,
  .line-controls {
    gap: 10px;
  }
  
  .size-display-container {
    min-width: 100px;
  }
  
  .size-display-container.editing {
    min-width: 120px;
  }
  
  .line-display {
    min-width: 100px;
  }
  
  .size-hint {
    font-size: 0.65rem;
  }
}
</style>
