Author: Daniel Pernicka (xpernid00)

<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  game: {
    getCurrentPlayer: () => string;
    isGameFinished: () => boolean;
    getScore: () => { xWins: number; oWins: number; ties: number };
  }
}>()

const getScore = computed(() => {
  return props.game.getScore()
})
</script>

<template>
  <div class="score-card-bottom">
    <div class="bottom-content">
      <div class="score-symbol" :class="{ 'active-player': game.getCurrentPlayer() === 'O' && !game.isGameFinished() }">
        <span class="symbol-o">O</span>
      </div>
      <div class="score-stats">
        <span class="wins">{{ getScore.oWins }}</span>
        <span class="separator">-</span>
        <span class="ties">{{ getScore.ties }}</span>
        <span class="separator">-</span>
        <span class="wins">{{ getScore.xWins }}</span>
      </div>
      <div class="score-symbol" :class="{ 'active-player': game.getCurrentPlayer() === 'X' && !game.isGameFinished() }">
        <span class="symbol-x">X</span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.score-card-bottom {
  position: relative;
  left: auto;
  transform: none;
  background: var(--theme-score-bg);
  border-radius: 12px;
  padding: 16px 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
  transition: all 0.3s ease;
  min-width: 300px;
  max-width: 100%;
  width: auto;
  margin-top: 20px;
}

.bottom-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 25px;
  width: 100%;
}

.score-symbol {
  width: 50px;
  height: 50px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  background: transparent;
  flex-shrink: 0;
}

.score-symbol.active-player {
  background: var(--theme-lines);
  transform: scale(1.05);
}

.symbol-o {
  font-size: 1.8rem;
  font-weight: 800;
  color: var(--theme-symbol-o);
}

.symbol-x {
  font-size: 1.8rem;
  font-weight: 800;
  color: var(--theme-symbol-x);
}

.score-stats {
  display: flex;
  align-items: center;
  gap: 20px;
  flex: 1;
  justify-content: center;
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--theme-button-text);
  background: color-mix(in srgb, var(--theme-score-bg) 90%, black);
  padding: 10px 20px;
  border-radius: 8px;
  min-width: 180px;
}

.wins, .ties {
  min-width: 30px;
  text-align: center;
}

.separator {
  color: color-mix(in srgb, var(--theme-button-text) 70%, transparent);
}

@media (max-width: 768px) {
  .score-card-bottom {
    min-width: 250px;
    max-width: 320px;
    padding: 12px 20px;
  }
  
  .bottom-content {
    gap: 15px;
  }
  
  .score-symbol {
    width: 40px;
    height: 40px;
  }
  
  .symbol-o,
  .symbol-x {
    font-size: 1.5rem;
  }
  
  .score-stats {
    font-size: 1.3rem;
    gap: 15px;
    min-width: 150px;
    padding: 8px 15px;
  }
}

@media (max-width: 480px) {
  .score-card-bottom {
    min-width: 220px;
    max-width: 280px;
    padding: 10px 15px;
  }
  
  .bottom-content {
    gap: 10px;
  }
  
  .score-symbol {
    width: 35px;
    height: 35px;
  }
  
  .symbol-o,
  .symbol-x {
    font-size: 1.3rem;
  }
  
  .score-stats {
    font-size: 1.1rem;
    gap: 10px;
    min-width: 130px;
    padding: 6px 12px;
  }
}
</style>
