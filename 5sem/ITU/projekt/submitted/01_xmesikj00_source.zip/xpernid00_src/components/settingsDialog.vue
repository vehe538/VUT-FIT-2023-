Author: Daniel Pernicka (xpernid00)

<script setup lang="ts">
const props = defineProps<{
  openRules: () => void
  openCustomization: () => void
  openMode: () => void
  closeSettings: () => void
}>()
</script>

<template>
  <div class="dialog-overlay" @click.self="closeSettings">
    <div class="settings-dialog">
      <button @click="closeSettings" class="dialog-exit-btn top-right-exit">
        <svg class="exit-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>

      <h2 class="dialog-title">Settings</h2>

      <div class="settings-buttons">
        <button @click="openRules" class="settings-menu-btn">
          <span class="btn-text">Rules</span>
        </button>
        
        <button @click="openCustomization" class="settings-menu-btn">
          <span class="btn-text">Customization</span>
        </button>
        
        <button @click="openMode" class="settings-menu-btn">
          <span class="btn-text">Mode</span>
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(4px);
}

.settings-dialog {
  background: var(--theme-bg);
  border-radius: 20px;
  padding: 40px;
  width: 90%;
  max-width: 500px;
  position: relative;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  animation: dialogSlideIn 0.3s ease;
}

@keyframes dialogSlideIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.settings-dialog .dialog-exit-btn.top-right-exit {
  position: absolute;
  top: 20px;
  right: 20px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: var(--theme-button-bg);
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}

.settings-dialog .dialog-exit-btn.top-right-exit:hover {
  background: color-mix(in srgb, var(--theme-button-bg) 80%, white);
  transform: rotate(90deg);
}

.dialog-title {
  text-align: center;
  color: var(--theme-lines);
  margin-bottom: 30px;
  font-size: 2rem;
  font-weight: 700;
  letter-spacing: 1px;
}

.settings-buttons {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.settings-menu-btn {
  background: var(--theme-score-bg);
  border: none;
  border-radius: 12px;
  padding: 20px 30px;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.settings-menu-btn:hover {
  background: color-mix(in srgb, var(--theme-score-bg) 80%, black);
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
}

.settings-menu-btn:active {
  transform: translateY(0);
}

.btn-text {
  color: var(--theme-button-text);
  font-size: 1.2rem;
  font-weight: 600;
  letter-spacing: 0.5px;
  font-family: 'Inter', sans-serif;
}

.exit-icon {
  width: 20px;
  height: 20px;
  color: var(--theme-button-text);
  stroke-width: 2.5;
}
</style>
