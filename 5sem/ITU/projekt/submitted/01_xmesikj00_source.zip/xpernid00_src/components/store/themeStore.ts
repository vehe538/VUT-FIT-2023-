// Author: Daniel Pernicka (xpernid00)

import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { ColorTheme } from '../../api/customAPI'

export const useThemeStore = defineStore('theme', () => {
  const themes = ref<ColorTheme[]>([
    {
      id: 'default',
      name: 'Classic',
      colors: {
        symbolO: '#3498db',
        background: '#C7C9AC',
        symbolX: '#e74c3c',
        lines: '#2D2D2D',
        buttonBg: '#2D2D2D',
        buttonText: '#FFFFFF',
        scoreBg: '#90A38B',
        cellBg: 'transparent'
      }
    },
    {
      id: 'classic-inverted',
      name: 'Classic Inverted',
      colors: {
        symbolO: '#e74c3c',
        background: '#2D2D2D',
        symbolX: '#3498db',
        lines: '#C7C9AC',
        buttonBg: '#C7C9AC',
        buttonText: '#2D2D2D',
        scoreBg: '#90A38B',
        cellBg: 'transparent'
      }
    },
    {
      id: 'ocean',
      name: 'Ocean',
      colors: {
        symbolO: '#48dbfb',
        background: '#0a3d62',
        symbolX: '#f8c291',
        lines: '#e6e6e6',
        buttonBg: '#0c2461',
        buttonText: '#c3eaf7ff',
        scoreBg: '#1e3799',
        cellBg: 'transparent'
      }
    },
    {
      id: 'sunset',
      name: 'Sunset',
      colors: {
        symbolO: '#ff9ff3',
        background: '#feca57',
        symbolX: '#ff6b6b',
        lines: '#222f3e',
        buttonBg: '#ff9f43',
        buttonText: '#222f3e',
        scoreBg: '#ff9f43',
        cellBg: 'transparent'
      }
    },
    {
      id: 'forest',
      name: 'Forest',
      colors: {
        symbolO: '#b6d11dff',
        background: '#2ecc71',
        symbolX: '#e66767',
        lines: '#34495e',
        buttonBg: '#27ae60',
        buttonText: '#FFFFFF',
        scoreBg: '#27ae60',
        cellBg: 'transparent'
      }
    },
    {
      id: 'midnight',
      name: 'Midnight',
      colors: {
        symbolO: '#9b59b6',
        background: '#2c3e50',
        symbolX: '#e67e22',
        lines: '#ecf0f1',
        buttonBg: '#34495e',
        buttonText: '#FFFFFF',
        scoreBg: '#34495e',
        cellBg: 'transparent'
      }
    },
    {
      id: 'candy',
      name: 'Candy',
      colors: {
        symbolO: '#00cec9',
        background: '#fab1a0',
        symbolX: '#a29bfe',
        lines: '#636e72',
        buttonBg: '#fd79a8',
        buttonText: '#FFFFFF',
        scoreBg: '#fd79a8',
        cellBg: 'transparent'
      }
    },
    {
      id: 'aurora',
      name: 'Aurora',
      colors: {
        symbolO: '#7ff0d9ff',
        background: '#0f3460',
        symbolX: '#ffa8b6ff',
        lines: '#7082a7ff',
        buttonBg: '#07aa8aff',
        buttonText: '#FFFFFF',
        scoreBg: '#0f8c73ff',
        cellBg: 'transparent'
      }
    },
    {
      id: 'midnight-gold',
      name: 'Midnight Gold',
      colors: {
        symbolO: '#f7b910ff',
        background: '#0a192fff',
        symbolX: '#ff6b9dff',
        lines: '#ffd700ff',
        buttonBg: '#ffd900a7',
        buttonText: '#0a192fff',
        scoreBg: '#87a3c8ff',
        cellBg: 'transparent'
      }
    },
    {
      id: 'chess',
      name: 'Chess',
      colors: {
        symbolO: '#fff2dcff',
        background: '#b09782ff',
        symbolX: '#2e2e2eff',
        lines: '#f0d9b5ff',
        buttonBg: '#656565ff',
        buttonText: '#c7a774ff',
        scoreBg: '#838383ff',
        cellBg: '#cfb58bff'
      }
    },
    {
      id: 'redWhiteBlue',
      name: 'Red, White & Blue',
      colors: {
        symbolO: '#dc2626ff',
        background: '#f8fafc',
        symbolX: '#2563ebff',
        lines: '#334155',
        buttonBg: '#2563ebff',
        buttonText: '#ffffff',
        scoreBg: '#ecb1b1ff',
        cellBg: 'transparent'
      }
    }
  ])

  const currentThemeId = ref('default')

  const currentTheme = computed(() => {
    return themes.value.find(theme => theme.id === currentThemeId.value) || themes.value[0]
  })

  const setTheme = (themeId: string) => {
    if (themes.value.some(theme => theme.id === themeId)) {
      currentThemeId.value = themeId
      localStorage.setItem('themeId', themeId)
      applyThemeToCSS()
    }
  }

  const applyThemeToCSS = () => {
    const theme = currentTheme.value
    const root = document.documentElement
    
    root.style.setProperty('--theme-bg', theme.colors.background)
    root.style.setProperty('--theme-symbol-o', theme.colors.symbolO)
    root.style.setProperty('--theme-symbol-x', theme.colors.symbolX)
    root.style.setProperty('--theme-lines', theme.colors.lines)
    root.style.setProperty('--theme-button-bg', theme.colors.buttonBg)
    root.style.setProperty('--theme-button-text', theme.colors.buttonText)
    root.style.setProperty('--theme-score-bg', theme.colors.scoreBg)
    root.style.setProperty('--theme-cell-bg', theme.colors.cellBg)
  }

  const initTheme = () => {
    const savedThemeId = localStorage.getItem('themeId')
    if (savedThemeId && themes.value.some(theme => theme.id === savedThemeId)) {
      currentThemeId.value = savedThemeId
    }
    applyThemeToCSS()
  }

  initTheme()

  return {
    themes,
    currentThemeId,
    currentTheme,
    setTheme,
    applyThemeToCSS
  }
})
